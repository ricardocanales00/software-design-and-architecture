public interface Item {
    public double getPrice();
}