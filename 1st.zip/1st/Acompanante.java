public abstract class Acompanante implements Item {
    @Override
    public abstract double getPrice(int size, boolean combo);
}