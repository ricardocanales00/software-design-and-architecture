public abstract class Bebida implements Item {
    @Override
    public abstract double getPrice(int size, boolean combo);
}